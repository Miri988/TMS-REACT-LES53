import { Homework } from "./pages/Homework/Homework";

function App() {
  return (
    <div>
      <Homework/>
    </div>
  );
}

export default App;
