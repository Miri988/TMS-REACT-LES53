import styles from "./Button.module.scss";

export const Button = (props) => {
    return <button className={styles.button}
    style = {props.style}
    type = {props.type} 
    onClick = {props.onClick}> {props.children} </button>;
}