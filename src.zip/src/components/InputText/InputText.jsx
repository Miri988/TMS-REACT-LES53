export const InputText = (props) => {
    return <input 
    type = "text" 
    onChange = {props.onChange} 
    value = {props.value}
    placeholder = {props.placeholder}
    />;
}