import styles from "./Notification.module.scss"


export const Notification = (props) => {
    return (
        <div className = {styles.notification}>
            <h6 className = {props.style} >{props.children}</h6>
        </div>
        
    )
    
}