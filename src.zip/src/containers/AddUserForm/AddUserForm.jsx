import { Button } from "../../components/Button/Button"
import { InputText } from "../../components/InputText/InputText"

export const AddUserForm = (props) => {
    return (
        <form onSubmit = {props.onSubmit}>
            <InputText placeholder = {props.placeholder} />
            <InputText placeholder = {props.placeholder} />
            <Button type = "submit"> Submit </Button>
        </form>
    )
}