import { Button } from "../../components/Button/Button";
import styles from "./ButtonGroupThree.module.scss";

const buttonList = [
  {
    id: 1,
    size: '20px',
    title: 'SMALL'
  },
  {
    id: 2,
    size: '28px',
    title: 'MEDIUM',
  },
  {
    id: 3,
    size: '32px',
    title: 'LARGE',
  },

];

export const ButtonGroupThree = () => {
    return (
        <div className={styles.buttonGroupThree}>
          {
            buttonList.map (item => 
            (
              <Button key = {item.id} style = {{fontSize: item.size}}>{item.title}</Button>
            )
            )
          }
        </div>
    )
}
