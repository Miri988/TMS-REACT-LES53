import { Notification} from "../../components/Notification/Notification";
import styles from "./NotificationGroup.module.scss";

const NotName = [
    {
      id: 1,
      title: 'error',
      description: 'This is an error alert - check it out!',
    },
    {
      id: 2,
      title: 'warning',
      description: 'This is a warning alert - check it out!!',
    },
    {
      id: 3,
      title: 'info',
      description: 'This is an info alert - check it out!',
    },
    {
      id: 4,
      title: "success",
      description: 'This is a success alert - check it out!',
    },
  ];

export const NotificationGroup = () => {
    
    return (
        <div className={styles.notificationGroup}>
            {
               NotName.map (item =>
                
                    <Notification key = {item.id} className = {item.title} >{item.description}</Notification>
                )
            }
        </div>
        
    )
}