import { ButtonGroupOne } from "../../containers/ButtonGroupOne/ButtonGroupOne";
import { ButtonGroupTwo } from "../../containers/ButtonGroupTwo/ButtonGroupTwo";
import { ButtonGroupThree } from "../../containers/ButtonGroupThree/ButtonGroupThree";
import { NotificationGroup } from "../../containers/NotificationGroup/NotificationGroup";

export const Homework = () => {
    return (
        <div className="App">
          <ButtonGroupOne />
          <ButtonGroupTwo />
          <ButtonGroupThree />
          <NotificationGroup />
        </div>
    )
}