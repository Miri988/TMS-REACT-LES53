import { AddUserForm } from "../../containers/AddUserForm/AddUserForm"
import { Footer } from "../../containers/Footer/Footer"


export const Main = () => {
    return (
        <div>
            <h1> Main Page</h1>
            <AddUserForm/>
            <Footer/>
        </div>
    )
}